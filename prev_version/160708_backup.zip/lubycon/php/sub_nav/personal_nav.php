<div class="contents_bt">
    <span class="global_icon"><i class="fa fa-bars"></i></span>
    <span class="subnav_selected">My Contents</span>
    <span class="subnav_arrow"><i class="fa fa-caret-down"></i></span>
    <ul class="subnav_list">
        <li id="my_contents">My Contents</li>
        <li id="message" style="display:none;">Message</li>
        <li id="bookmark">Bookmarks</li>
        <li id="account_setting">Account Setting</li>
    </ul>
</div>