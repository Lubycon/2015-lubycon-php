<option>Animation</option>
<option>Architecture</option>
<option>Avant-garde</option>
<option>Baroque</option>
<option>Design</option>
<option>Digital art</option>
<option>Drawing</option>
<option>Expressionism</option>
<option>Historical</option>
<option>Icons</option>
<option>Illustration</option>
<option>Impressionism</option>
<option>Landscape</option>
<option>Minimalism</option>
<option>Painting</option>
<option>Pop art</option>
<option>Protrait</option>
<option>Realism</option>
<option>Renaissance</option>
<option>Sculpture</option>
<option>Street art</option>
<option>Surrealism</option>
<option>Symbolism</option>
<option>UI/UX</option>
<option>Wallpaper</option>
<option>Web design</option>
<option>Various</option>