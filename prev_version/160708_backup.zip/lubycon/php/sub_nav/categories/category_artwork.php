<option>All Categories</option>
<option>Animation</option>
<option>Architecture</option>
<option>Avant-garde</option>
<option>Baroque</option>
<option>Design</option>
<option>Digital Art</option>
<option>Drawing</option>
<option>Expressionism</option>
<option>Historical</option>
<option>Icons</option>
<option>Illustrations</option>
<option>Impressionism</option>
<option>Landscape</option>
<option>Minimalism</option>
<option>Painting</option>
<option>Pop Art</option>
<option>Portrait</option>
<option>Realism</option>
<option>Renaissance</option>
<option>Sculpture</option>
<option>Street Art</option>
<option>Surrealism</option>
<option>Symbolism</option>
<option>UI/UX</option>
<option>Wallpaper</option>
<option>Web Design</option>
<option>Various</option>