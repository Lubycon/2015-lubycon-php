<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1-strict.dtd">
		<html lang="en">
		<head>
			<meta charset="UTF-8">
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		</head>
		<body>
		<table align="center" width="620" height="270" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0">
		<tbody>
			<tr id="mail_lubycon_logo">
				<td>
					<img src="../../CH/img/resist_mail/mail_header.png" class="mail_header" >
				</td>
			</tr>
        	<tr id="mail_hello">
            	<td align="left" style="font-family:Arial, Helvetica, sans-serif; font-size: 40px; color:#444444;">
                	<br />
                	 &nbsp;Hello. <font size="40px" color="#48cfad">:)</font>
                    <br />
                    <br />
                </td>
            </tr>
            <tr id="mail_description">
            	<td align="left" style="font-family:Arial, Helvetica, sans-serif; font-size: 15px; color:#444444; line-height:25px;">
           			&nbsp;&nbsp;&nbsp;
                    Your temporary password has been sent to the registered email.<br /><br />
					&nbsp;&nbsp;&nbsp;
					<font size="4px">
					Here your temporary password is : tMpi8b65wP4lkQPTXtfz
					</font>
					<br /><br />
					&nbsp;&nbsp;&nbsp;

					If this is not you, Please Contact.<br />
                    &nbsp;&nbsp;&nbsp;
                    <br />
                    <br />
            	</td>
            </tr>
            <tr>
                <td align="left" style="font-family:Arial, Helvetica, sans-serif; font-size: 15px; color:#444444; line-height:20px;">
                	<br />
                    &nbsp;&nbsp;&nbsp;
                	If you have any problems or questions, please send e-mail to 
                    <a id="mailadress" href="mailto:contact@lubycon.com" style="text-decoration:none;">
                    	<font color="#48cfad" size="+1">contact@lubycon.com</font>
                    </a>
                </td>
            </tr>
        </tbody>
		</table>
		</body>
		