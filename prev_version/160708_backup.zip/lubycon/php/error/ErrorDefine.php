<?php
#--------------------------------------------------------------------------
# Define about Error contents
#--------------------------------------------------------------------------
define("L_ERROR"								0001)
define("L_FAIL_QUERY",							0002);
define("L_FAIL_SEND_EMAIL", 					0004);
define("L_INPUT_UNSUITABLE_DATA"				0008);
define("L_EMPTY_SESSION_VALUE"					0016);

?>