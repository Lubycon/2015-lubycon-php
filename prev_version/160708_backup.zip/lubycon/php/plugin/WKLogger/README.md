WKLogger
==
<br/>
WKlogger is Wrap <a href="https://github.com/katzgrau/KLogger">KLogger</a>.
<br/><br/>
Features:
  - Daily Looging. 
  