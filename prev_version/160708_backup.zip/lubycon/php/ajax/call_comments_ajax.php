<?php
    for($i=1; $i<=20; $i++){
        include("../layout/comment.php");
    };
?>