<?php
	//IF PARAMETER IS NOT EXIST, IT WILL BE SHOWED 'undefined'
	$cate_param = $_POST['cate_param'];
	$middle_category = $_POST['mid_cate_param'];
	$cc_param = $_POST['cc_param'];
	$filter_param = $_POST['filter_param'];
	$job_param = $_POST['job_param'];
	$location_param = $_POST['job_param'];
	$search_filter_param = $_POST['search_filter_param'];

	echo $_POST;
?>