<?php
	include_once('../personal_page/modifyWindow.php');
?>