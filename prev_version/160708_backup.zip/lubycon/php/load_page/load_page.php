<?php
include("php/".$_GET['1']."/".$_GET['2'].".php");
?>
