<link rel="stylesheet" href="../../css/layout/common.css" />
<section>
    <div class="coming_soon">
        <figure class="coming_soon_img">
            <img src="./ch/img/coming_soon/coming_soon_logo.png" />
        </figure>
        <div class="coming_soon_bt">
            <a href="javascript:history.back()">
                <img src="./ch/img/coming_soon/coming_soon_bt.svg" />
            </a>
        </div>
    </div>
</section>
