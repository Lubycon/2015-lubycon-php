<ul>
    <?php
     $contents_cate = 'forum';
     include("../layout/main_board.php");
    ?>
</ul>
