<?php 
	echo 1; //TRUE, else -> return 0
?>