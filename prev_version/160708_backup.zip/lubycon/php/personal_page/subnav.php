<?php
$id = $_POST['id'];
echo $id;

?>