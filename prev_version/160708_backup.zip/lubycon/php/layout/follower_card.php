<li>
    <div class="follower_card_body">
        <div class="follower_pic">
        	<img src="CH/img/about_us/employee/dart.png" />
        </div>
        <div class="follower_info">
        	<p class="follower_name">Dart</p>
        	<p class="follower_job">Web Designer</p>
        	<p class="follower_location">Seoul, South Korea</p>
        </div>
        <div class="follow_bt_body">
        	<button class="follow_card_bt">
        		<i class="fa fa-user-plus"></i>
        	</button>
        </div>
    </div>
</li>
