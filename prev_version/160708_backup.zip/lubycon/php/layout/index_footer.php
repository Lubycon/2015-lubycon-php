    <div id="gotop_bt"><i class="fa fa-angle-up"></i></div>
    <footer id="footer" class="footer">
        <span id="luby_copyright"><i class="fa fa-copyright"></i>2016 Lubycon</span>
        <span id="about_lubycon" class="hidden-mb-ib">
            <span id="about_us_foot"><a href="<?=$two_depth?>/company/about_us.php">About us</a></span>
            <span id="contact_us_foot"><a href="mailto:contact@lubycon.com" target="_blank">Contact us</a></span>
        </span>
        <span id="luby_link">
            <a href="#"><i class="fa fa-facebook-square"></i></a>
            <a href="#"><i class="fa fa-twitter-square"></i></a>
            <a href="#"><i class="fa fa-google-plus-square"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
            <a href="#"><i class="fa fa-pinterest-square"></i></a>
            <a href="#"><i class="fa fa-tumblr-square"></i></a>
        </span>
        <span id="luby_policies" class="hidden-mb-ib">
            <span id="termsOfService_foot"><a href="<?=$two_depth?>/company/terms_of_service.php" class="document">Terms of service</a></span>
            <span id="privatePolicy_foot"><a href="<?=$two_depth?>/company/private_policy.php" class="document">Private policy</a></span>
        </span>
    </footer>   <!--end footer-->
</div>
</body>
</html>