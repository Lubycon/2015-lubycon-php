<section class="mb-wrapper-main visible-mb">
    <?php
        
    ?>
    <section class="mb-section">
        <div class="mb-main-img-wrapper selected" data-value="artwork">
            <ul>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/artwork/1.jpg" alt="content1" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/artwork/2.jpg" alt="content2" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/artwork/3.jpg" alt="content3" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/artwork/4.jpg" alt="content4" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/artwork/5.jpg" alt="content5" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>
            <div class="viewmore_bt">
                <a href="./php/contents/contents_page.php?cate=artwork&mid_cate=1&page=1">VIEW MORE ARTWORK</a>
            </div>
        </div>
        <div class="mb-main-img-wrapper" data-value="vector">
            <ul>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/vector/1.jpg" alt="content1" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/vector/2.jpg" alt="content2" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/vector/3.jpg" alt="content3" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/vector/4.jpg" alt="content4" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/vector/5.jpg" alt="content5" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>
            <div class="viewmore_bt">
                <a href="./php/contents/contents_page.php?cate=vector&mid_cate=1&page=1">VIEW MORE VECTOR</a>
            </div>
        </div>
        <div class="mb-main-img-wrapper" data-value="3d">
            <ul>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/3d/1.jpg" alt="content1" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/3d/2.jpg" alt="content2" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/3d/3.jpg" alt="content3" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/3d/4.jpg" alt="content4" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
                <li class="mb-main-img">
                    <a href="#">
                        <img src="./ch/img/thumbnail/3d/5.jpg" alt="content5" />
                        <div class="layer">
                            <div class="content-descript">
                                <p class="content-name">LOREM IPSUM</p>
                                <p class="creator-name">by <span>Simon Joseph</span></p>
                            </div>
                        </div>
                    </a>
                </li>
            </ul>
            <div class="viewmore_bt">
                <a href="./php/contents/contents_page.php?cate=threed&mid_cate=1&page=1">VIEW MORE 3D MODEL</a>
            </div>
        </div>
    </section>
    <div id="mb-main-tab">
        <div class="mb-main-tab-wrapper">
            <div class="mb-main-tab-bt btn radioType selected" data-target="artwork">
                <i class="fa fa-picture-o"></i><span>ARTWORK</span>
            </div>
            <div class="mb-main-tab-bt btn radioType" data-target="vector">
                <i class="fa fa-object-group"></i><span>VECTOR</span>
            </div>
            <div class="mb-main-tab-bt btn radioType" data-target="3d">
                <i class="fa fa-cube"></i><span>3D MODEL</span>
            </div>
        </div>
    </div>
</section>