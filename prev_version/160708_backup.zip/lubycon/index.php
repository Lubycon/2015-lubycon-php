<?php
    $one_depth = '.'; //css js load
    $two_depth = './php'; // php load
    include_once($one_depth.'/php/layout/index_header.php');
    include_once($one_depth.'/index_body.php');
    include_once($one_depth.'/php/layout/index_footer.php');
?>